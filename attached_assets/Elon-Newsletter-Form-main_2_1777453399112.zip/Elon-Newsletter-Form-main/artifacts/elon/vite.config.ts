import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

const isProduction = process.env.NODE_ENV === "production";
const isReplit = !!process.env.REPL_ID;

export default defineConfig(async () => {
  const plugins = [react()];

  // Only load Replit plugins in Replit development
  if (!isProduction && isReplit) {
    try {
      const cartographer = await import("@replit/vite-plugin-cartographer");
      const banner = await import("@replit/vite-plugin-dev-banner");
      const runtime = await import("@replit/vite-plugin-runtime-error-modal");

      if (cartographer.default) plugins.push(cartographer.default());
      if (banner.default) plugins.push(banner.default());
      if (runtime.default) plugins.push(runtime.default());
    } catch (error) {
      console.log("Replit dev plugins skipped");
    }
  }

  return {
    plugins,

    resolve: {
      alias: {
        "@": path.resolve(__dirname, "./src"),
      },
    },

    build: {
      sourcemap: false,
      outDir: "dist",
      emptyOutDir: true,
    },

    server: {
      host: "0.0.0.0",
      port: 5173,
    },
  };
});
